//
//  presenterManager.swift
//  Unveil
//
//  Created by Arafat Hussain on 10/01/2021.
//

import UIKit

class presenterManager {
    static let shared  = presenterManager()
    
    private init() {}
    
    enum VC {
        case mainTabBarController
        case onboarding
    }
    
    func show (vc: VC) {
        
        var viewController: UIViewController
        
        switch vc {
        case .mainTabBarController:
            viewController = UIStoryboard(name: K.storyBoardID.Main, bundle: nil).instantiateViewController(identifier: K.storyBoardID.MainTabBarController)
        case .onboarding:
            viewController = UIStoryboard(name: K.storyBoardID.Main, bundle: nil).instantiateViewController(identifier: K.storyBoardID.onboardingViewController)
        }
        
        if let sceneDelegate = UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate, let window = sceneDelegate.window {
            window.rootViewController = viewController
            UIView.transition(with: window, duration: 0.25, options: .transitionCrossDissolve, animations: nil, completion: nil)
        }
    }
}
