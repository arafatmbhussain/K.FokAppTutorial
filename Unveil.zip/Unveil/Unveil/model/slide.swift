//
//  slide.swift
//  Unveil
//
//  Created by Arafat Hussain on 08/01/2021.
//

import Foundation

struct slide {
    let imageName: String
    let title: String
    let description: String
    
    
    static let collection: [slide] = [
        slide(imageName: "allweddingservices", title: "title 1", description: "para 1"),
        slide(imageName: "addfriends", title: "title 2", description: "para 2"),
        slide(imageName: "budget", title: "title 3", description: "para 3"),
        slide(imageName: "Pindream", title: "title 4", description: "para 4")
    ]
}
