//
//  LoginViewController.swift
//  Unveil
//
//  Created by Arafat Hussain on 09/01/2021.
//

import UIKit

class LoginViewController: UIViewController {
    
    weak var delegate: onboardingDelegate?
    
    private let isSuccessfulLogin = false
    
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var retypePasswordTextField: UITextField!
    @IBOutlet weak var errorLabel: UILabel!
    @IBOutlet weak var forgottenPasswordButton: UIButton!
    @IBOutlet weak var signUpButton: UIButton!
    @IBOutlet weak var loginButton: UIButton!
    
    private enum pageType {
        case login
        case signUp
    }
    
    private var errorMessage: String? {
        didSet {
            showErrorMessageIfNeeded(text: errorMessage)
        }
    }
    
    private var currentPageType: pageType = .login {
        didSet {
            setUpViewsFor(pageType: currentPageType)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpViewsFor(pageType: pageType .login)
    }
    
    private func setUpViewsFor(pageType: pageType) {
        errorMessage = nil
        retypePasswordTextField.isHidden = pageType == .login
        signUpButton.isHidden = pageType == .login
        forgottenPasswordButton.isHidden = pageType == .signUp
        loginButton.isHidden = pageType == .signUp
    }
    
    private func showErrorMessageIfNeeded(text: String?) {
        errorLabel.isHidden = text == nil
        errorLabel.text = text
    }
    
    
    @IBAction func forgottenPasswordButtonTapped(_ sender: Any) {
    }
    
    @IBAction func signUpButtonTapped(_ sender: Any) {
    }
    
    @IBAction func loginButtonTapped(_ sender: Any) {
        
        if isSuccessfulLogin {
            delegate?.showMainTabBarController()
        } else {
            errorMessage = "Your password is invalid. Please try again."
        }
    }
    
    @IBAction func segmentedControlChanged (_ sender: UISegmentedControl) {
        currentPageType = sender.selectedSegmentIndex == 0 ? .login : .signUp

    }
}
