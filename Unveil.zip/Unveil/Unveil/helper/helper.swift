//
//  helper.swift
//  Unveil
//
//  Created by Arafat Hussain on 08/01/2021.
//

import Foundation

func delay (durationInSeconds seconds: Double, completion: @escaping () -> Void) {
    DispatchQueue.main.asyncAfter(deadline: .now() + seconds, execute: completion)
}
