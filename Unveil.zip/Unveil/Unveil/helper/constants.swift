//
//  constants.swift
//  Unveil
//
//  Created by Arafat Hussain on 08/01/2021.
//

import Foundation

struct K {
    struct segue {
        static let ShowOnboarding = "ShowOnboarding"
        static let ShowLoginSignUp = "ShowLoginSignUp"
    }


struct storyBoardID {
        static let Main = "Main"
        static let MainTabBarController = "MainTabBarController"
        static let onboardingViewController = "onboardingViewController"
    }
}
